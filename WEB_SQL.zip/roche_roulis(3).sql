-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : lun. 28 avr. 2025 à 08:52
-- Version du serveur : 9.1.0
-- Version de PHP : 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `roche&roulis`
--

-- --------------------------------------------------------

--
-- Structure de la table `albums`
--

DROP TABLE IF EXISTS `albums`;
CREATE TABLE IF NOT EXISTS `albums` (
  `id_album` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_album` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id_album`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `artistes`
--

DROP TABLE IF EXISTS `artistes`;
CREATE TABLE IF NOT EXISTS `artistes` (
  `id_groupe` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_groupe` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `membres_groupe` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `date_formation` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `description` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `id_ville` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id_groupe`),
  KEY `key_ville` (`id_ville`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `artistes`
--

INSERT INTO `artistes` (`id_groupe`, `nom_groupe`, `membres_groupe`, `date_formation`, `description`, `id_ville`) VALUES
(14, 'Ultra vomit', 'Fetus ( Nicolas ) dans le rôle du chanteur / guitariste Manard ( Emmanuel ) dans le rôle du batteur ', '2000-2008', 'Ultra Vomit est un groupe de heavy metal parodique français, originaire de Nantes, en Loire-Atlantique. À ses débuts, le groupe est initialement influencé par le grindcore. Ses morceaux contiennent généralement des paroles humoristiques avec un côté volontairement absurde, influencées par le monde des dessins animés, des comédies humoristiques, de la publicité et de la culture populaire en général. Une partie de leur répertoire est constituée de reprises du Top 50.', 14);

-- --------------------------------------------------------

--
-- Structure de la table `chansons`
--

DROP TABLE IF EXISTS `chansons`;
CREATE TABLE IF NOT EXISTS `chansons` (
  `id_chanson` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_chanson` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `lien_musique` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `id_groupe` int UNSIGNED NOT NULL,
  `id_album` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id_chanson`),
  KEY `groupe_key` (`id_groupe`),
  KEY `album_key` (`id_album`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `departements`
--

DROP TABLE IF EXISTS `departements`;
CREATE TABLE IF NOT EXISTS `departements` (
  `id_departement` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_departement` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id_departement`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `departements`
--

INSERT INTO `departements` (`id_departement`, `nom_departement`) VALUES
(1, 'Ain'),
(2, 'Aisne'),
(3, 'Allier'),
(4, 'Alpes de Haute-Provence'),
(5, 'Hautes-Alpes'),
(6, 'Alpes-Maritimes'),
(7, 'Ardêche'),
(8, 'Ardennes'),
(9, 'Ariège'),
(10, 'Aube'),
(11, 'Aude'),
(12, 'Aveyron'),
(13, 'Bouches-du-Rhône'),
(14, 'Calvados'),
(15, 'Cantal'),
(16, 'Charente'),
(17, 'Charente-Maritime'),
(18, 'Cher'),
(19, 'Corrèze'),
(21, 'Côte-d`Or'),
(22, 'Côtes d`Armor'),
(23, 'Creuse'),
(24, 'Dordogne'),
(25, 'Doubs'),
(26, 'Drôme'),
(27, 'Eure'),
(28, 'Eure-et-Loir'),
(29, 'Finistère'),
(30, 'Gard'),
(31, 'Haute-Garonne'),
(32, 'Gers'),
(33, 'Gironde'),
(34, 'Hérault'),
(35, 'Îlle-et-Vilaine'),
(36, 'Indre'),
(37, 'Indre-et-Loire'),
(38, 'Isère'),
(39, 'Jura'),
(40, 'Landes'),
(41, 'Loir-et-Cher'),
(42, 'Loire'),
(43, 'Haute-Loire'),
(44, 'Loire-Atlantique'),
(45, 'Loiret'),
(46, 'Lot'),
(47, 'Lot-et-Garonne'),
(48, 'Lozère'),
(49, 'Maine-et-Loire'),
(50, 'Manche'),
(51, 'Marne'),
(52, 'Haute-Marne'),
(53, 'Mayenne'),
(54, 'Meurthe-et-Moselle'),
(55, 'Meuse'),
(56, 'Morbihan'),
(57, 'Moselle'),
(58, 'Nièvre'),
(59, 'Nord'),
(60, 'Oise'),
(61, 'Orne'),
(62, 'Pas-de-Calais'),
(63, 'Puy-de-Dôme'),
(64, 'Pyrénées-Atlantiques'),
(65, 'Hautes-Pyrénées'),
(66, 'Pyrénées-Orientales'),
(67, 'Bas-Rhin'),
(68, 'Haut-Rhin'),
(69, 'Rhône'),
(70, 'Haute-Saône'),
(71, 'Saône-et-Loire'),
(72, 'Sarthe'),
(73, 'Savoie'),
(74, 'Haute-Savoie'),
(75, 'Paris'),
(76, 'Seine-Maritime'),
(77, 'Seine-et-Marne'),
(78, 'Yvelines'),
(79, 'Deux-Sèvres'),
(80, 'Somme'),
(81, 'Tarn'),
(82, 'Tarn-et-Garonne'),
(83, 'Var'),
(84, 'Vaucluse'),
(85, 'Vendée'),
(86, 'Vienne'),
(87, 'Haute-Vienne'),
(88, 'Vosges'),
(89, 'Yonne'),
(90, 'Territoire-de-Belfort'),
(91, 'Essonne'),
(92, 'Hauts-de-Seine'),
(93, 'Seine-Saint-Denis'),
(94, 'Val-de-Marne'),
(95, 'Val-d`Oise');

-- --------------------------------------------------------

--
-- Structure de la table `donne`
--

DROP TABLE IF EXISTS `donne`;
CREATE TABLE IF NOT EXISTS `donne` (
  `id_groupe` int UNSIGNED NOT NULL,
  `id_evenement` int UNSIGNED NOT NULL,
  `date_evenement` date NOT NULL,
  `lieu_evenement` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id_groupe`,`id_evenement`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `evenements`
--

DROP TABLE IF EXISTS `evenements`;
CREATE TABLE IF NOT EXISTS `evenements` (
  `id_evenement` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_evenement` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id_evenement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `styles_musique`
--

DROP TABLE IF EXISTS `styles_musique`;
CREATE TABLE IF NOT EXISTS `styles_musique` (
  `id_style` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_style` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`id_style`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `styles_musique`
--

INSERT INTO `styles_musique` (`id_style`, `nom_style`) VALUES
(1, 'Hard Rock'),
(2, 'Punk Rock'),
(3, 'Alternative Rock'),
(4, 'Progressive Rock'),
(5, 'grunge Rock'),
(6, 'Pop Rock'),
(7, 'pop punk'),
(8, 'Blues Rock'),
(9, 'Punk Hardcore'),
(10, 'pop alternative nordique'),
(11, 'Rock alternatif'),
(12, 'groove'),
(13, 'Stoner'),
(14, 'Ska Punk'),
(15, 'Heavy Metal'),
(16, 'Thrash Metal'),
(17, 'Death Metal'),
(18, 'Progressive Metal'),
(19, 'Black Metal'),
(20, 'Power Metal'),
(21, 'Symphonic Metal'),
(22, 'Doom Metal'),
(23, 'Nu Metal'),
(24, 'Rap Metal'),
(25, 'Metal alternatif'),
(26, 'Catégorie Skate / rock'),
(27, 'Metal moderne'),
(28, 'Deathcore'),
(29, 'Néofolk'),
(30, 'Breakcore / Electro metal');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id_user` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `mail_user` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password_user` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `mail` (`mail_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id_user`, `nom_user`, `mail_user`, `password_user`) VALUES
(2, 'smauroy', 'smauroy@myges.fr', '$2y$10$KMM9nzCTqngy3GguyD5Esez3mNBQdlYxwa9e4N/Re8z4U.Jhahexe');

-- --------------------------------------------------------

--
-- Structure de la table `villes`
--

DROP TABLE IF EXISTS `villes`;
CREATE TABLE IF NOT EXISTS `villes` (
  `id_ville` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_ville` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `id_departement` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id_ville`),
  KEY `key_departement` (`id_departement`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `villes`
--

INSERT INTO `villes` (`id_ville`, `nom_ville`, `id_departement`) VALUES
(1, 'Nantes', 44),
(2, 'Nantes', 44),
(3, 'Nantes', 44),
(4, 'Nantes', 44),
(5, 'Nantes', 44),
(6, 'Nantes', 44),
(7, 'Nantes', 44),
(8, 'Nantes', 44),
(9, 'Nantes', 44),
(10, 'Nantes', 44),
(11, 'Nantes', 44),
(12, 'Nantes', 44),
(13, 'Nantes', 44),
(14, 'Nantes', 44);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `artistes`
--
ALTER TABLE `artistes`
  ADD CONSTRAINT `fk_groupe_ville` FOREIGN KEY (`id_ville`) REFERENCES `villes` (`id_ville`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `chansons`
--
ALTER TABLE `chansons`
  ADD CONSTRAINT `fk_chanson_album` FOREIGN KEY (`id_album`) REFERENCES `albums` (`id_album`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_chanson_groupe` FOREIGN KEY (`id_groupe`) REFERENCES `artistes` (`id_groupe`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `villes`
--
ALTER TABLE `villes`
  ADD CONSTRAINT `fk_ville_departement` FOREIGN KEY (`id_departement`) REFERENCES `departements` (`id_departement`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
