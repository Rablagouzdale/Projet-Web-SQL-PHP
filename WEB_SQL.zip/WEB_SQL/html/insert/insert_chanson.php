<?php include("../login/login_BDD.php"); ?>

<?php

// Récupération des données du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titre = $_POST['titre'];
    $url = $_POST['url'];
    $id_album = $_POST['id_album'];
    $id_artiste = $_POST['id_artiste'];

    // Requête pour insérer le nom de l'album et l'id du groupe (url) dans la BDD
    $sql_chanson = "INSERT INTO chansons (nom_chanson, url_youtube, id_album)
    VALUES (:titre, :url, :id_album)";
    // Préparation de la requête d'insertion de la chanson
    $result = $pdo->prepare($sql_chanson);

    // On exécute la requête
    $result->execute([
        ':titre' => $titre,
        ':url' => $url,
        ':id_album' => $id_album
    ]);

    // Si la requête s'est correctement exécutée → redirection + message
    if ($result !== false) {
        header("Location: ../fiche_admin.php?id=".$id_artiste);
        echo "L'album été ajouté avec succès.";
    } else { // La requête n'a pas abouti → affiche message d'erreur qui renvoie la description détaillée de l'erreur SQL
        echo "Erreur lors de l'insertion de l'artiste.";
    }
}
?>