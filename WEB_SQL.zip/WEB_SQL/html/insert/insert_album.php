<?php

include("../login/login_BDD.php");

// Récupération des données du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $album = $_POST['album'];
    $id_artiste = $_POST['id_artiste'];
    $id_style = $_POST['genre'];

    // Requête pour insérer le nom de l'album et l'id du groupe (url) dans la BDD
    $sql_album = "INSERT INTO albums (nom_album, id_groupe)
    VALUES (:album, :id_artiste)";
    // Préparation de la requête d'insertion de l'album
    $result = $pdo->prepare($sql_album);

    // On exécute la requête
    $result->execute([
    ':album' => $album,
    ':id_artiste' => $id_artiste
    ]);

    // Récupérer l'ID de l'album insérée
    $id_album = $pdo->lastInsertId();

    // Requête pour insérer le nom de l'album et l'id du groupe (url) dans la BDD
    $sql_album_style = "INSERT INTO album_style (id_album, id_style)
    VALUES (:id_album, :id_style)";
    // Préparation de la requête d'insertion de l'album
    $result_follow = $pdo->prepare($sql_album_style);

    // On exécute la requête
    $result_follow->execute([
    ':id_album' => $id_album,
    ':id_style' => $id_style
    ]);


    // Si la requête s'est correctement exécutée → redirection + message
    if ($result !== false) {
        header("Location: ../fiche_admin.php?id=".$id_artiste);
        echo "L'album été ajouté avec succès.";
    } else { // La requête n'a pas abouti → affiche message d'erreur qui renvoie la description détaillée de l'erreur SQL
        echo "Erreur lors de l'insertion de l'artiste.";
    }
    
}
?>