<?php

include("../login/login_BDD.php");

// Récupération des données du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name =  $_POST['name'];
    $membres = $_POST['membres'];
    $departement = $_POST['departement'];
    $date_formation = $_POST['date_formation'];
    $description = $_POST['description'];
    $id_user = $_POST['id_user'];

    // Insertion des données de la fiche complétée par l'user dans la table artiste
    $sql_artiste = "INSERT INTO artistes (nom_groupe, membres_groupe, id_departement, date_formation, description)
    VALUES (:name, :membres, :dep, :date, :description)"; // En préparant la requête ainsi on sécurise les valeurs renseignées

    // Prepare et exécute la requête d'insertion de l'artiste
    $result = $pdo->prepare($sql_artiste);
    $result->execute([
        ':name' => $name,
        ':membres' => $membres,
        ':dep' => $departement,
        ':date' => $date_formation,
        ':description' => $description

    ]);

    // Récupérer l'ID de l'artiste insérée
    $id_artiste = $pdo->lastInsertId();

    // Insertion de l'id_artiste créé dans la colonne id_groupe de l'utilisateur
    if (!empty($id_user)) {
        $sql_user = "UPDATE utilisateurs SET id_groupe = :id_artiste WHERE id = :id_user";
        $update = $pdo->prepare($sql_user);
        $update->execute([
            ':id_artiste' => $id_artiste,
            ':id_user' => $id_user
        ]);
    } else {
        echo "ID utilisateur manquant !";
    }

    // Si la requête s'est correctement exécutée → redirection + message
    if ($result !== false) {
        header("Location: ../form/se_connecter.php?id=" . $id_artiste);
        echo "L'artiste a été ajouté avec succès.";
    } else { // La requête n'a pas abouti → affiche message d'erreur qui renvoie la description détaillée de l'erreur SQL
        echo "Erreur lors de l'insertion de l'artiste.";
    }
}

?>