<?php

include("../login/login_BDD.php");

// Récupération des données du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name =  $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password1'];

    // Hashage du mot de passe : on le transforme en une chaîne illisible grâce à un algorithme de hashage
    $password_hashed = password_hash($password, PASSWORD_DEFAULT);


    // On prévoit d'insérer les données utilisateur du formulaire → dans les colonnes de la table utilisateurs présente sur phpmyadmin
    $sql = "INSERT INTO utilisateurs (nom_user, mail_user, password_user)
    VALUES (:name, :email, :password)"; // En préparant la requête ainsi on sécurise les valeurs renseignées

    // stmt = statement → instruction
    // On prépare la requête SQL
    $stmt = $pdo->prepare($sql);

    // On exécute la requête
    $stmt->execute([
    ':name' => $name,
    ':email' => $email,
    ':password' => $password_hashed
    ]);

    // Récupérer l'ID de l'artiste insérée
    $id_user = $pdo->lastInsertId();

    // Redirection avec ajout de l'id_user dans l'url
    header("Location: ../form/create_fiche.php?id=".$id_user);
    echo "<font color='whitesmoke'>Utilisateur ajouté avec succès !</font>";
}

?>