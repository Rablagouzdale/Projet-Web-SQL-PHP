<?php
echo "
<footer>
        <p id='bas_page'>©️2025 Gaël PETIT et Séverine MAUROY
            <br>Tous droits réservés - Source image : Freepik</p>
</footer>
";
?>