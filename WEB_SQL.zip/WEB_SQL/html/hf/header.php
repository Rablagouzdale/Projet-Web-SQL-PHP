<?php
echo "
<header>
    <nav>
        <div class='titre'>
            <h1>Roche<br>&<br>Roulis</h1>
        </div>
        
        <div class='link'>
            <ul>
                <li class='no_point'><a id='l1' href='./accueil.php'>Accueil</a></li>
                <li class='no_point'><a id='l2' href='#artistes'>Artistes du Mois</a></li>
                <li class='no_point'><a id='l3' href='#sorties'>Sorties du Mois</a></li>
                <li class='no_point'><a id='l4' href='./annuaire.php'>Annuaire</a></li>
                <li class='no_point'><a id='l5' href='./apropos.php'>A Propos</a></li>
                </ul>
        </div>
    </nav>
</header>
";
?>