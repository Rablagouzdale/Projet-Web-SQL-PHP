<?php

include("../login/login_BDD.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];

    // Requête pour supprimer l'artiste de la base de donnée
    $delete = $pdo->prepare("DELETE FROM artistes WHERE id=:id");
    $delete->execute([':id' => $id]);
    //echo "Le groupe a été supprimé.";

    header("Location: ../accueil.php");
}
?>
