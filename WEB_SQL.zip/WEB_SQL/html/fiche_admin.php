<!DOCTYPE html> <!-- Version 5 de HTML-->
<html lang="fr"> <!-- Précision de la langue pour le navigateur-->

<head> <!-- Entête du document HTML -->

    <meta charset="UTF-8"> <!-- précise l'encodage des caractère à UTF-8-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css" /> <!--Lien vers le fichier de style css-->
    <script type="text/javascript" src="../js/script.js"></script> <!--Lien vers le fichier javascript-->

    <title>Roche&Roulis</title> <!-- titre qui s'affiche dans le navigateur -->

</head>

<body>

    <div class="page">
        <!-- Entête de la page web -->
        <?php include("./hf/header.php"); ?>

        <!-- Section fiche du groupe -->
        <div class="section">
            <h2>Fiche du Groupe</h2>

            <div class="en_tete">
                <!-- Traitement photo suspendu -->
                <div class="picture">
                    <img alt="photo du groupe" />
                </div>

                <!-- Affichage des données du groupe présentes dans la BDD -->
                <div class="infos">
                    <ul>
                        <!-- Modification du nom -->
                        <li class='element'>
                            <button class="button_fiche_artiste" onclick="modif_nom()">🖉</button><strong>Nom du groupe :</strong>
                            <?php include("./login/artiste_BDD.php"); ?>
                            <?php echo $groupe; ?>
                            <!-- Formulaire caché, en ligne -->
                            <form id="form_nom" action="" method="POST">
                                <input type="text" name="nouveau_nom" placeholder="Nouveau_nom" required>
                                <input type="submit">
                            </form>
                        </li>

                        <?php
                        // Requete sql qui permet de modifier le nom du groupe
                        if (isset($_POST['nouveau_nom'])) {
                            $nouveau_nom = $_POST['nouveau_nom'];
                            $update = $pdo->prepare("UPDATE artistes SET nom_groupe = ? WHERE id = ?");
                            $update->execute([$nouveau_nom, $_GET['id']]);
                        } ?>
                        </li>

                        <!-- Modification des membres -->
                        <li class='element'>
                            <button class="button_fiche_artiste" onclick="modif_membres()">🖉</button><strong>Membres du groupe :</strong>
                            <?php include("./login/artiste_BDD.php"); ?>
                            <?php echo $membres; ?>
                            <!-- Formulaire caché, en ligne -->
                            <form id="form_membres" action="" method="POST">
                                <input type="text" name="nouveaux_membres" placeholder="nouveaux_membres" required>
                                <input type="submit">
                            </form>
                        </li>
                        <?php
                        // Requete sql qui permet de modifier les membres du groupe
                        if (isset($_POST['nouveaux_membres'])) { // On utilise isset pour vérifier qu'il renvoie faux si la variable n'existe pas
                            $nouveaux_membres = $_POST['nouveaux_membres'];
                            $update = $pdo->prepare("UPDATE artistes SET membres_groupe = ? WHERE id = ?");
                            $update->execute([$nouveaux_membres, $$_GET['id']]);
                        }
                        ?>
                        </li>

                        <!-- Modification du département -->
                        <li class='element'>
                            <button class="button_fiche_artiste" onclick="modif_dep()">🖉</button><strong>Originaire de :</strong>
                            <?php include("./login/artiste_BDD.php"); ?>
                            <?php echo $dep; ?>
                            <!-- Formulaire caché, en ligne -->
                            <form id="form_dep" action="" method="POST">
                                <input type="text" name="nouvelle_origine" placeholder="nom du departement " required>
                                <input type="submit">
                            </form>
                        </li>
                        <?php
                        // Requete sql qui permet de modifier l'origine du groupe
                        if (isset($_POST['nouvelle_origine'])) {
                            $nom_departement = $_POST['nouvelle_origine'];

                            // la requête récupère l'id du département
                            $stmt = $pdo->prepare("SELECT id FROM departements WHERE nom_departement = ?");
                            $stmt->execute([$nom_departement]);
                            $departement = $stmt->fetch(PDO::FETCH_ASSOC);

                            if ($departement) {
                                $update = $pdo->prepare("UPDATE artistes SET id_departement = ? WHERE id = ?");
                                $update->execute([$departement['id'], $_GET['id']]);
                            }
                        }
                        ?>

                        <!-- Modification de la date de formation du groupe -->
                        <li class='element'>
                            <button class="button_fiche_artiste" onclick="modif_date()">🖉</button><strong>Groupe formé en :</strong>
                            <?php include("./login/artiste_BDD.php"); ?>
                            <?php echo $date; ?>
                            <!-- Formulaire caché, en ligne -->
                            <form id="form_date" action="" method="POST">
                                <input type="text" name="date_formation" placeholder="année de formation" required>
                                <input type="submit">
                            </form>
                        </li>
                        <?php
                        // Requete sql qui permet de modifier la date de formation du groupe
                        if (isset($_POST['date_formation'])) {
                            $date_formation = $_POST['date_formation'];
                            $update = $pdo->prepare("UPDATE artistes SET date_formation = ? WHERE id = ?");
                            $update->execute([$date_formation, $_GET['id']]);
                        }
                        ?>
                        <li class='element'><strong>Style(s) musical(aux) :</strong> </li>
                        <?php include("./login/style_BDD.php"); ?>
                    </ul>
                </div>
            </div>

            <!-- Affichage de la description du groupe présente dans la BDD -->
            <div class="descript">
                <p><strong>Description :</strong></p>
                <p>
                    <?php include("./login/artiste_BDD.php"); ?>
                    <?php echo $description; ?>
                </p>
            </div>

            <!-- Affichage des albums et chansons du groupe présents dans la BDD -->
            <h2>Liste des albums</h2>
            <div class="descript">
                <?php include("./login/album_BDD.php"); ?>
                <button onclick="ajouter_album()">Ajouter un Album</button>
            </div>

            <!-- Formulaire d'ajout d'album dans la BDD -->
            <div class="descript" id="form_album">
                <form action="./insert/insert_album.php" method="POST">
                    <!-- Input pour cacher l'id de l'url dans le formulaire -->
                    <input type="hidden" name="id_artiste" value="<?php echo $_GET['id']; ?>">
                    <p>
                        <label>Nom de l'Album: <span class="red">*</span></label>
                        <input type="text" name="album" id="id_album" class="champs" required />
                    </p>
                    <p>
                        <label>Choisir un Style de Musique: <span class="red">*</span></label>
                        
                        <!-- Construction d'une liste déroulante à partir des données de la BDD -->
                        <select name="genre" required>
                            <option value="">-- Sélectionnez un genre --</option>
                            <?php include("./login/style_BDD.php"); ?>
                            <?php foreach ($resultat as $r): ?>
                                <option value="<?= $r['id'] ?>">
                                    <?= $r['nom_style'] ?>
                                </option>
                            <?php endforeach; ?>
                            <p>Styles sélectionnés :</p>
                            <ul id="liste_styles"></ul>

                            <!-- Champ caché où tous les styles sélectionnés seront stockés -->
                            <input type="hidden" name="styles" id="styles_input">
                        </select>
                    </p>
                    <input type="submit" name="ajout_album" id="insert_album" value="Ajouter" />

                </form>
            </div>

            <!-- Formulaire d'ajout de chanson dans la BDD -->
            <div class="descript" id="form_chanson">
                <form action="./insert/insert_chanson.php" method="POST">
                    <!-- Input pour cacher l'id de l'url dans le formulaire -->
                    <input type="hidden" name="id_artiste" value="<?php echo $_GET['id']; ?>">
                    <input type="hidden" name="id_album" id="input_album" value="">
                    <p>
                        <label>Titre de la chanson : <span class="red">*</span></label>
                        <input type="text" name="titre" id="id_titre" class="champs" required />
                    </p>
                    <p>
                        <label>URL Youtube : <span class="red">*</span></label>
                        <input type="text" name="url" id="id_url" class="champs" required />
                        <input type="submit" name="ajout_chanson" id="insert_chanson" value="Ajouter" />
                    </p>
                </form>
            </div>

            <!-- Suppression de la fiche du groupe -->
            <div class="descript">
                <form action="./delete/delete.php" method="POST">
                    <!-- utilisation du type hidden pour pas que l'utilisateur voit -->
                    <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
                    <button type="submit" id="suppr" onclick="return confirm_delete()">Supprimer le groupe</button>
                </form>
            </div>
        </div>

    </div>
<!-- Bas de la page web et copyright -->
    <?php include("./hf/footer.php"); ?>
    
</body>

</html>