<!DOCTYPE html> <!-- Version 5 de HTML-->
<html lang="fr"> <!-- Précision de la langue pour le navigateur-->

<head> <!-- Entête du document HTML -->

    <meta charset="UTF-8"> <!-- précise l'encodage des caractère à UTF-8-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css" /> <!--Lien vers le fichier de style css-->
    <script type="text/javascript" src="../js/script.js"></script> <!--Lien vers le fichier javascript-->

    <title>APropos</title> <!-- titre qui s'affiche dans le navigateur -->

</head>

<div class="page">
    <!-- Entête de la page web -->
    <?php include("./hf/header.php"); ?>

    <!-- Section suspendue -->
    <div class="section">
        <h2>A propos de nous</h2>


    </div>

</div>

<!-- Bas de la page web et copyright -->
<?php include("./hf/footer.php"); ?>

</html>