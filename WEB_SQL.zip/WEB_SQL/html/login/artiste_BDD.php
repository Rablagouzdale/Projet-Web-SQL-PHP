<?php

include("login_BDD.php");


$id_artiste = isset($_GET['id']) ? (int) $_GET['id'] : null; // Récupère l'id présent dans l'url
 
if ($id_artiste === null) {
    echo "ID artiste invalide.";
}

// Requête pour lier les tables artistes et départements 
$sql = "SELECT * FROM artistes INNER JOIN departements ON artistes.id_departement = departements.id WHERE artistes.id=:id_artiste;";
$sth = $pdo->prepare($sql);
$sth->execute([':id_artiste' => $id_artiste]);
$resultat = $sth->fetchAll(PDO::FETCH_ASSOC);

// Boucle traitant chaque ligne de $resultat
foreach ($resultat as $r) {
    $groupe = $r['nom_groupe'];
    $membres = $r['membres_groupe'];
    $dep = $r['nom_departement'];
    $date = $r['date_formation'];
    $description = $r['description'];
}

?>