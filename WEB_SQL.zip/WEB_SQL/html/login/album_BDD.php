<?php

include("login_BDD.php");

$id_artiste = isset($_GET['id']) ? $_GET['id'] : null; // Récupère l'id présent dans l'url

// Requête pour lier les tables artistes, albums et chansons
$sql = "SELECT albums.id AS id_album, albums.nom_album, chansons.nom_chanson, chansons.url_youtube  FROM artistes INNER JOIN albums ON albums.id_groupe = artistes.id LEFT JOIN chansons ON albums.id = chansons.id_album  WHERE artistes.id=:id_artiste;";
$sth = $pdo->prepare($sql);
$sth->execute([':id_artiste' => $id_artiste]); // Sécurisation de l'id_artiste
$resultat = $sth->fetchAll(PDO::FETCH_ASSOC);

// Création d'un tableau vide pour regrouper et stocker les albums

$albums = [];

// Boucle traitant chaque ligne de $resultat
foreach ($resultat as $r) {
    $id_album = $r['id_album'];
    $nom_album = $r['nom_album'];
    $nom_chanson = $r['nom_chanson'];
    $lien_url = $r['url_youtube'];

    // Si l’album n’existe pas encore dans le tableau $albums
    if (!isset($albums[$nom_album])) {
        $albums[$nom_album] = [
            'id_album' => $id_album,
            'chansons' => []
        ];
    }

    // Ajouter la chanson seulement si elle existe
    if (!empty($nom_chanson)) {
        $albums[$nom_album]['chansons'][] = [
            'chanson' => $nom_chanson,
            'url' => $lien_url
        ];
    }
    // En procédant ainsi on évite d'écraser les données précédentes à chaque boucle
}

// Affichage du listing des albums et chansons
foreach ($albums as $nom_album => $donnees_album) {
    $id_album = $donnees_album['id_album'];
    $chansons = $donnees_album['chansons'];

    // Affichage de l'album
    echo "<p><strong>" . $nom_album . "&nbsp;</strong>";
    echo "<button id='button_ajout' title='Ajouter une chanson' onclick='ajouter_chanson(" . $id_album . ")'>+</button></p>";
    echo "<ol>";

    // Boucle pour afficher des chansons
    foreach ($chansons as $chanson) {
        $titre = $chanson['chanson'];
        $url = $chanson['url'];
        echo "<li>" . $titre . " — <a href='" . $url . "' target='_blank'>Lien Youtube</a></li>";
    }
    echo "</ol>";
}

?>