<?php

include("login_BDD.php");

// Récupération des données du formulaire
$keywords = isset($_GET["keywords"]) ? trim($_GET["keywords"]) : ""; // on vérifie si Keyword existe et n'ai pas nul , on récupère les espaces inutiles au début et à la fin avec trim
$valider = isset($_GET["valider"]) ? $_GET["valider"] : "";
$results = []; // Tableau pour stoquer le résultat


// SI l'utilistateur a cliqué sur le sur rechercher et que le champ n'est pas vide 
if ($valider && !empty($keywords)) {
    // Requete sql pour rechercher les groupes dans la base de données
    $stmt = $pdo->prepare("SELECT * FROM artistes WHERE nom_groupe LIKE :search");
    $stmt->execute(['search' => "%$keywords%"]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC); //  résultats dans un tableau 
}
?>