<?php

include("login_BDD.php");

$id_artiste = isset($_GET['id']) ? $_GET['id'] : null; // Récupère l'id présent dans l'url

// Requête pour lier les tables albums, album_style et styles_musique
$sql = "SELECT artistes.id, albums.nom_album, album_style.id_album, album_style.id_style, styles_musique.nom_style FROM artistes INNER JOIN albums ON artistes.id = albums.id_groupe INNER JOIN album_style ON albums.id = album_style.id_album INNER JOIN styles_musique ON album_style.id_style = styles_musique.id WHERE artistes.id =:id_artiste";
$sth = $pdo->prepare($sql);
$sth->execute([':id_artiste' => $id_artiste]);
$result = $sth->fetchAll(PDO::FETCH_ASSOC);

// Création d'un tableau vide pour regrouper et stocker les genres
$genres = [];

foreach ($result as $r) {
    $genres[] = $r['nom_style'];
}

// Si le tableau n’est pas vide, on affiche les styles
if (!empty($genres)) {
    foreach ($genres as $genre) {
        echo "<li class='no_point'>" . $genre . "</li>";
    }
} else {
    echo "<li class='no_point'>(aucun style trouvé)</li>";
}

// Requête pour récupérer les styles de musique
$sql = "SELECT * FROM styles_musique ORDER BY nom_style ASC";
$sth = $pdo->prepare($sql);
$sth->execute();
$resultat = $sth->fetchAll(PDO::FETCH_ASSOC);
?>