<?php

include("login_BDD.php");

session_start(); // Démarrer la session pour pouvoir utiliser $_SESSION

// Vérifie que le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'];
    $password_submit = $_POST['password'];

    // Requête pour trouver l'email de l'user dans la table utilisateurs de la base donnée 
    $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE mail_user = :email");
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Vérifie que le mot de passe utilisateur entré correspond à celui enregistré dans la base   
    if ($user && password_verify($password_submit, $user['password_user'])) {
        // Connexion réussie
        $_SESSION['id'] = $user['id']; 
        $_SESSION['nom_user'] = $user['nom_user']; 
        $_SESSION['id_groupe'] = $user['id_groupe']; 

        // Rediriger vers une page d'accueil si tu veux :
        header("Location: ../accueil.php");
    } else {
        echo "Email ou mot de passe incorrect.";
    }
}
?>