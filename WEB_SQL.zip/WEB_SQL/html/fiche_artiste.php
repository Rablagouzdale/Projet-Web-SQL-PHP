<!DOCTYPE html> <!-- Version 5 de HTML-->
<html lang="fr"> <!-- Précision de la langue pour le navigateur-->

<head> <!-- Entête du document HTML -->

    <meta charset="UTF-8"> <!-- précise l'encodage des caractère à UTF-8-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css" /> <!--Lien vers le fichier de style css-->
    <script type="text/javascript" src="../js/script.js"></script> <!--Lien vers le fichier javascript-->

    <title>Roche&Roulis</title> <!-- titre qui s'affiche dans le navigateur -->

</head>

<body>

    <div class="page">
        <!-- Entête de la page web -->
        <?php include("./hf/header.php"); ?>

        <!-- Section fiche du groupe -->
        <div class="section">
            <h2>Fiche du Groupe</h2>

            <div class="en_tete">
                <!-- Traitement photo suspendu -->
                <div class="picture">
                    <img alt="photo du groupe" />
                </div>

                <!-- Affichage des données du groupe présentes dans la BDD -->
                <div class="infos">
                    <ul>
                        <li class='element'><strong>Nom du groupe :</strong>
                            <?php include("./login/artiste_BDD.php"); ?>
                            <?php echo $groupe; ?>
                        </li>
                        <li class='element'><strong>Membres du groupe :</strong>
                            <?php include("./login/artiste_BDD.php"); ?>
                            <?php echo $membres; ?>
                        </li>
                        <li class='element'><strong>Originaire de :</strong>
                            <?php include("./login/artiste_BDD.php"); ?>
                            <?php echo $dep; ?>
                        </li>
                        <li class='element'><strong>Groupe formé en :</strong>
                            <?php include("./login/artiste_BDD.php"); ?>
                            <?php echo $date; ?>
                        </li>
                        <li class='element'><strong>Style(s) musical(aux) :</strong> </li>
                        <?php include("./login/style_BDD.php"); ?>
                    </ul>
                </div>
            </div>

            <!-- Affichage de la description du groupe présente dans la BDD -->
            <div class="descript">
                <p><strong>Description :</strong></p>
                <p>
                    <?php include("./login/artiste_BDD.php"); ?>
                    <?php echo $description; ?>
                </p>
            </div>

            <!-- Affichage des albums et chansons du groupe présents dans la BDD -->
            <h2>Liste des albums</h2>
            <div class="descript">
                <?php include("./login/album_BDD.php"); ?>
            </div>

        </div>

        <!-- Fonction pour faire disparaître les boutons de la page -->
        <script>
            window.addEventListener('DOMContentLoaded', function() {
                const boutons = document.querySelectorAll('button');
                boutons.forEach(function(bouton) {
                    bouton.style.display = 'none';
                });
            });
        </script>

    </div>

    <!-- Bas de la page web et copyright -->
    <?php include("./hf/footer.php"); ?>

</body>

</html>