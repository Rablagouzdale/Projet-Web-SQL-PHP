<!DOCTYPE html> <!-- Version 5 de HTML-->
<html lang="fr"> <!-- Précision de la langue pour le navigateur-->

<head> <!-- Entête du document HTML -->

    <meta charset="UTF-8"> <!-- précise l'encodage des caractère à UTF-8-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css" /> <!--Lien vers le fichier de style css-->
    <script type="text/javascript" src="../js/script.js"></script> <!--Lien vers le fichier javascript-->

    <title>Annuaire</title> <!-- titre qui s'affiche dans le navigateur -->

</head>

<body>

    <div class="page">

        <!-- Entête de la page web -->
        <?php include("./hf/header.php"); ?>

        <!-- Bouton de connexion -->
        <div class="section" id="session_button">
            <button id='button_login' onclick='connexion()'>Connexion</button>
        </div>

        <div class="section" id="session">

            <!-- Affichage de la section utilisateur (utilise id, nom d'user et id_groupe s'il y en a un) -->
            <?php include("./login/login_session.php"); ?>
            <?php
            if (isset($_SESSION['id'])) {

                // S'il a un groupe, afficher le bouton
                if (!empty($_SESSION['id_groupe'])) {
                    echo "Bonjour, " . $_SESSION['nom_user'];
                    echo "<br><button onclick='go_fiche(" . $_SESSION['id_groupe'] . "," . $_SESSION['id'] . ")'>Ma Fiche</button>";
                } else {
                    echo "Bonjour, " . $_SESSION['nom_user'];
                }
            } else {
                echo "Bienvenue !";
            }
            ?> <!-- Permet de définir l'accessibilité du site selon statut de l'user -->
        </div>

        <!-- Sections suspendues -->
        <div class="section" id="artistes">
            <h2>Artistes du Mois</h2>
        </div>

        <div class="section" id="sorties">
            <h2>Sorties du Mois</h2>
        </div>

    </div>
    <!-- Bas de la page web et copyright -->
    <?php include("./hf/footer.php"); ?>
</body>


</html>