<!DOCTYPE html> <!-- Version 5 de HTML-->
<html lang="fr"> <!-- Précision de la langue pour le navigateur-->

<head> <!-- Entête du document HTML -->

    <meta charset="UTF-8"> <!-- précise l'encodage des caractère à UTF-8-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../css/sessions.css" /> <!--Lien vers le fichier de style css-->
    <script type="text/javascript" src="../../js/script.js"></script> <!--Lien vers le fichier javascript-->

    <title>Roche&Roulis</title> <!-- titre qui s'affiche dans le navigateur -->
</head>

<body class = "connect">

<header>
<a href="../accueil.php" >Retour Accueil</a>
</header>

<div class="container">
        <h1>se connecter</h1>

        <form action="../login/login_session.php" method="POST">

            <label class="space">👤 E-mail de l'utilisateur : <span class="red">*</span></label>
            <input type="email" name="email" id="id_email" required oninput="champs_connexion()">


            <label class="space"> Mot de passe : <span class="red">*</span></label>
            <input type="password" name="password" id="id_password" required oninput="champs_connexion()">

            <input type="submit" name="soumettre" class="submit_button" id="submit_connexion" value="Connexion">


            <p class="p2">Pas de compte utilisateur ?</p>
            <p><a href="./choice.php">S'inscrire</a></p>
        </form>
</div>
    <!-- Bas de la page web et copyright -->
    <?php include("../hf/footer.php"); ?>

</body>
</html>