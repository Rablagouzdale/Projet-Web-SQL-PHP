<!DOCTYPE html> <!-- Version 5 de HTML-->
<html lang="fr"> <!-- Précision de la langue pour le navigateur-->

<head> <!-- Entête du document HTML -->

    <meta charset="UTF-8"> <!-- précise l'encodage des caractère à UTF-8-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../css/create.css" /> <!--Lien vers le fichier de style css-->
    <script type="text/javascript" src="../../js/script.js"></script> <!--Lien vers le fichier javascript-->

    <title>Roche&Roulis</title> <!-- titre qui s'affiche dans le navigateur -->

</head>

<body class="connect">

    <header>
        <a href="../accueil.php">Retour Accueil</a>
    </header>

    <!-- Page de création d'une fiche pour le groupe -->
    <div class="container">
        <h1>Création d'une fiche Artiste</h1>
        <p>Merci de remplir les champs suivants :</p>

        <!-- Formulaire de renseignement -->
        <form action="../insert/insert_artiste.php" method="POST">

            <div class="en_tete">
                <div class="picture">

                </div>
                <div class="infos">
                    <!-- Input pour cacher l'id de l'url dans le formulaire -->
                    <input type="hidden" name="id_user" value="<?php echo htmlspecialchars($_GET['id']); ?>">

                    <ul>
                        <!-- Input : nom du groupe -->
                        <li class='element'>
                            <label>Nom du groupe : <span class="red">*</span></label>
                            <input type="text" name="name" id="id_name" required oninput="confirmer()" />
                        </li>
                        <!-- Textaera : membres du groupe -->
                        <li class='element'>
                            <label>Membres du groupe : <span class="red">*</span></label>
                            <textarea name="membres" id="id_membres" required oninput="confirmer()"></textarea>
                        </li>
                        <!-- Input : département -->
                        <li class='element'>
                            <label>Originaire de : <span class="red">*</span>
                            <span id="msg_dep">Erreur : la saisie est invalide</span></label> 
                            <input type="number" name="departement" id="id_departement" placeholder="N° département" min="01" max="95" required oninput="confirmer()">
                        </li>
                        <!-- Input : date de formation -->
                        <li class='element'>
                            <label>Année de formation du groupe : <span class="red">*</span></label>
                            <input type="text" name="date_formation" id="id_date" required oninput="confirmer()" />
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Textaera : description -->
            <div class="descript">
                <label>Présentation du groupe : <span class="red">*</span></label>
                <textarea name="description" id="id_description" required oninput="confirmer()"></textarea>
            </div>
            <input type="submit" name="create" class="submit_button" id="submit_create" value="Confirmer" disabled onclick="direct_connect()" />

        </form>
    </div>
    <!-- Bas de la page web et copyright -->
    <?php include("../hf/footer.php"); ?>

</body>

</html>