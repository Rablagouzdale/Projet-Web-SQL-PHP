<!DOCTYPE html> <!-- Version 5 de HTML-->
<html lang="fr"> <!-- Précision de la langue pour le navigateur-->

<head> <!-- Entête du document HTML -->

    <meta charset="UTF-8"> <!-- précise l'encodage des caractère à UTF-8-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../css/sessions.css" /> <!--Lien vers le fichier de style css-->
    <script type="text/javascript" src="../../js/script.js"></script> <!--Lien vers le fichier javascript-->

    <title>Roche&Roulis</title> <!-- titre qui s'affiche dans le navigateur -->

</head>

<body class="connect">

    <header>
        <a href="../accueil.php">Retour Accueil</a>
    </header>

    <!-- Page d'inscription : administrateur -->
    <div class="container">
        <h1>Inscription :
            <br>Artiste
        </h1>
        <p>Merci de remplir les champs suivants :</p>

        <!-- Formulaire de renseignement -->
        <form action="../insert/insert_admin.php" method="POST">

            <label class="space">Nom d'utilisateur : <span class="red">*</span></label>
            <input type="text" name="name" id="id_name" required />

            <label class="space">E-Mail : <span class="red">*</span></label>
            <input type="email" name="email" id="id_email" required />

            <label class="space">Mot de passe : <span class="red">*</span></label>
            <input type="password" name="password1" id="id_password1" required />

            <label class="space">Confirmer le mot de passe : <span class="red">*</span></label>
            <input type="password" name="password2" id="id_password2" oninput="verif_password()" />
            <!-- Messages dynamiques pour guider l'utilisateur dans sa démarche -->
            <p id="msg_erreur">Erreur: Les mots de passe ne sont pas identiques</p>
            <p id="msg_valid">Les mots de passe sont identiques</p>

            <input type="submit" name="soumettre" class="submit_button" id="submit_verif" value="Inscription" disabled onclick="direct_artiste()" />

        </form>
    </div>
    <!-- Bas de la page web et copyright -->
    <?php include("../hf/footer.php"); ?>

</body>

</html>