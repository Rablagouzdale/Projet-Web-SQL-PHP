<!DOCTYPE html> <!-- Version 5 de HTML-->
<html lang="fr"> <!-- Précision de la langue pour le navigateur-->

<head> <!-- Entête du document HTML -->

    <meta charset="UTF-8"> <!-- précise l'encodage des caractère à UTF-8-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../css/sessions.css" /> <!--Lien vers le fichier de style css-->
    <script type="text/javascript" src="../../js/script.js"></script> <!--Lien vers le fichier javascript-->

    <title>Roche&Roulis</title> <!-- titre qui s'affiche dans le navigateur -->

</head>

<body class="connect">

    <header>
        <a href="../accueil.php">Retour Accueil</a>
    </header>

    <!-- Page de choix status utilisateur -->
    <div class="container">
        <h1>Inscription</h1>
        <p>Choisissez votre status utilisateur :</p>

        <!-- Bouton utilisateur -->
        <div class="button_choice">
            <button id="user" onclick="inscription_user ()">Utilisateur</button>
            <p id="msg_user">Compte utilisateur :
                <br>Vous êtes utilisateur et vous souhaitez accéder à l'espace commentaires ?
                <br>Cliquez ici pour vous inscrire
            </p>
        </div>
        <!-- Bouton administrateur -->
        <div class="button_choice">
            <button id="admin" onclick="inscription_admin ()">Artiste</button>
            <p id="msg_admin">Compte Artiste :
                <br>Vous êtes artiste et vous souhaitez faire connaître votre groupe ?
                <br>Cliquez ici pour vous inscrire et créer votre page dédiée
            </p>
        </div>
        <!-- Bouton help -->
        <div class="button_choice">
            <p class="p2">Connaître le détail de chaque rôle :</p>
            <button onclick="afficher_msg ()">En Savoir Plus</button>
        </div>
    </div>

    <!-- Bas de la page web et copyright -->
    <?php include("../hf/footer.php"); ?>

</body>

</html>