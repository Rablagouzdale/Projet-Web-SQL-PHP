<!DOCTYPE html> <!-- Version 5 de HTML-->
<html lang="fr"> <!-- Précision de la langue pour le navigateur-->

<head> <!-- Entête du document HTML -->

    <meta charset="UTF-8"> <!-- précise l'encodage des caractère à UTF-8-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css" /> <!--Lien vers le fichier de style css-->
    <script type="text/javascript" src="../js/script.js"></script> <!--Lien vers le fichier javascript-->

    <title>Roche&Roulis</title> <!-- titre qui s'affiche dans le navigateur -->

</head>

<body>

    <div class="page">
        <!-- Entête de la page web -->
        <?php include("./hf/header.php"); ?>

        <div class="section" id="recherche">

            <?php include("./login/search_BDD.php"); ?>

            <!-- Barre de recherche -->
            <form method="get" action="">

                <!-- Champ de texte où l'utilisateur tape le nom du groupe -->
                <input type="text" name="keywords" placeholder="Nom du groupe" value="<?php echo $keywords; ?>">

                <!-- Bouton pour lancer la recherche -->
                <input type="submit" name="valider" value="Rechercher">
            </form>


            <!-- htmlspecialchars :  Convertit les caractères spéciaux en entités -->


            <?php if ($valider): ?> <!-- Si l'utilisateur a cliqué sur le bouton "Rechercher" -->
                <div id="resultats">

                    <?php if (!empty($results)): ?> <!-- Si on trouve des résultats ça nous affiche le nombre de résultat trouvés -->
                        <p><?php echo count($results); ?> résultat(s) trouvé(s) :</p>

                        <!-- On parcourt ensuite chaque groupe -->
                        <?php foreach ($results as $groupe): ?>
                            <div class="groupe-profil">
                                <!-- Affiche le nom du groupe -->
                                <h2><?php echo "<a href='./fiche_artiste.php?id=" . $groupe['id']  . "'>" . $groupe['nom_groupe'] . "</a>"; ?></h2>

                                <!-- Affiche les membres du groupe -->
                                <p><strong>Membres :</strong> <?php echo $groupe['membres_groupe']; ?></p>

                                <!-- Affiche la date de formation -->
                                <p><strong>Date de formation :</strong> <?php echo $groupe['date_formation']; ?></p>

                                <!-- Affiche la description (avec les retours à la ligne respectés grâce à nl2br) -->
                                <p><strong>Description :</strong> <?php echo nl2br($groupe['description']); ?></p>
                            </div>
                            <hr>
                        <?php endforeach; ?>

                    <?php else: ?>
                        <!-- Si aucun groupe ne correspond à la recherche -->
                        <p>Aucun groupe trouvé pour "<?php echo $keywords; ?>".</p>
                    <?php endif; ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bas de la page web et copyright -->
    <?php include("./hf/footer.php"); ?>

</body>

</html>