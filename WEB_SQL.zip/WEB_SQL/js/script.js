// Fonctions messsages
function direct_connect() {
    alert("Merci de votre inscription !\nVous allez être redirigé vers la page de connexion.");
}
function direct_artiste() {
    alert("Merci de votre inscription !\nVous allez être redirigé vers la page création d'une fiche dédiée à votre groupe.");
}
function afficher_msg() {
    document.getElementById("msg_user").style.display = "block";
    document.getElementById("msg_admin").style.display = "block";
}


// Functions de formulaire avec conditions de changement de couleurs selon validité
function verif_password() { // Fonction pour vérifier la concordance des mdp
    var mdp1 = document.getElementById('id_password1');
    var mdp2 = document.getElementById('id_password2');
    var msg_ok = document.getElementById('msg_valid');
    var msg_nok = document.getElementById('msg_erreur');
    var submit = document.getElementById('submit_verif');
    
    if (mdp1.value !== mdp2.value) {
        msg_ok.style.display = "none";
        msg_nok.style.display = "block";
        submit.style.backgroundColor = "grey";
        submit.disabled = true;
    } else {
        msg_ok.style.display = "block";
        msg_nok.style.display = "none";
        submit.style.backgroundColor = "#4caf50";
        submit.disabled = false;
    }
};
function confirmer() { // Fonction de contrôle pour le champs des départements
    var input1 = document.getElementById('id_name');
    var input2 = document.getElementById('id_membres');
    var input3 = document.getElementById('id_departement');
    var input4 = document.getElementById('id_date');
    var input5 = document.getElementById('id_description');
    var msg_dep = document.getElementById('msg_dep');
    var submit = document.getElementById('submit_create');

    if (input3.value > "95") {
        msg_dep.style.display = "block";
        submit.style.backgroundColor = "grey";
    }
    else {
        msg_dep.style.display = "none";
        if (input1.value === "" || input2.value === "" || input3.value === "" || input4.value === "" || input5.value === "") {
            submit.style.backgroundColor = "grey";
            submit.disabled = true;
        } else {
            submit.style.backgroundColor = "#4caf50";
            submit.disabled = false;
        }
    }
}
function champs_connexion () {
    var email = document.getElementById('id_email');
    var mdp = document.getElementById('id_password');
    var submit = document.getElementById('submit_connexion');

    if (email.value === "" || mdp.value === "") {
        submit.style.backgroundColor = "grey";
    } else {
        submit.style.backgroundColor = "#4caf50";
    }
}


// Fonctions de redirection
function connexion() {
    window.location.href = './form/se_connecter.php';
}
function inscription_user() {

    if (window.confirm("Vous confirmez votre choix ?")) {
        window.location.href = 'inscription_user.php';
    }
}
function inscription_admin() {

    if (window.confirm("Vous confirmez votre choix ?")) {
        window.location.href = 'inscription_admin.php';
    }
}


function go_fiche(id_groupe, id) { // Fonction liée au bouton "Ma Fiche"
    
    // S'il y a un id_groupe associé → redirige vers la fiche du groupe (mode admin)
    if (id_groupe) {
        window.location.href = './fiche_admin.php?id=' + id_groupe;
    }
    else {
        // S'il n'y a pas d'id_groupe associé → propose de créer une fiche (mode admin)
        if (window.confirm("Voulez-vous créer une fiche pour votre groupe ?")) {
            return window.location.href = './form/create_fiche.php?id=' + id;
        } else {
            console.log("Création annulée");
        }
        
    }

}


// Fonctions d'apparition des champs d'ajouts
function ajouter_album() {
    document.getElementById("form_album").style.display = "block";
    document.getElementById("form_chanson").style.display = "none";
}
function ajouter_chanson(id) {
    document.getElementById("form_album").style.display = "none";
    document.getElementById("form_chanson").style.display = "block";
    document.getElementById("input_album").value = id;
}


// Fonctions d'apparition des champs de modifications
function modif_nom() {
    document.getElementById("form_nom").style.display = "block";
}
function modif_membres() {
    document.getElementById("form_membres").style.display = "block";
}
function modif_dep() {
    document.getElementById("form_dep").style.display = "block";
}
function modif_date() {
    document.getElementById("form_date").style.display = "block";
}


function confirm_delete() { // Fonction pour confirmer la suppression
    return window.confirm("Etes vous sûr de vouloir supprimer la fiche de votre groupe ?");

}